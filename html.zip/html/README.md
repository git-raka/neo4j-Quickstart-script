# Web Content Directory
After building the application with `npm run build`, deploy this folder (now renamed from `public` to `build`) to your webserver.